package com.example.wandersyncteam10.Model;

public class modelClass {
}
